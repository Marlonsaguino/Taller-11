# Taller API REST - Biblioteca

Autores: Marlon Rainier Aguiño Salinas y Jonathan Abraham Perez Chiquito.

Entidad: libros (`id`, `titulo`, `autor`). Node.js + Express, SQLite real y JWT.
La consigna establece trabajo y pregunta técnica individuales; confirmar con el docente la presentación con dos autores.

## Instalación y ejecución

Requiere Node.js 24.15 o superior y npm. SQLite viene integrado en Node (`node:sqlite`); no necesita un servidor adicional.
Abrir una terminal en esta carpeta:

```sh
npm ci
npm run setup
npm run init-user
npm start
```

`setup` crea `.env` con un secreto JWT aleatorio, puerto 3000 y ruta `./data/biblioteca.sqlite`.
No reemplaza un `.env` existente. `.env.example` documenta las variables sin valores secretos.
`init-user` pide un usuario y una contraseña local de 12 a 256 caracteres. La entrada de contraseña es visible en la terminal: usar una contraseña exclusiva de prueba.
Almacena únicamente un hash scrypt con sal aleatoria. Repetir el comando con el mismo usuario cambia su contraseña.
La cuenta no se incluye en el ZIP; cada instalación debe inicializarla.
También admite `TEST_USER` y `TEST_PASSWORD` como variables de entorno locales para inicialización automática; borrarlas después.

Servidor: `http://127.0.0.1:3000`. No se incluye interfaz gráfica.
La base y las tablas se crean automáticamente usando `schema.sql`. Al detener Node, el archivo SQLite permanece en `data/`.

## Rutas

| Método | Ruta | Resultado |
|---|---|---|
| POST | /auth/login | 200 con JWT; 401 si credenciales incorrectas |
| POST | /libros | 201, identificador y cabecera Location |
| GET | /libros | 200, lista |
| GET | /libros/:id | 200 o 404 |
| PUT | /libros/:id | 200 o 404 |
| DELETE | /libros/:id | 204 o 404 |

Solo el login es público. Todas las rutas `/libros` requieren `Authorization: Bearer <token>`.
Un token ausente, inválido, con firma incorrecta o vencido produce 401 antes de consultar o modificar libros.
JWT: HS256, vencimiento 15 minutos, emisor `biblioteca-api` y audiencia `biblioteca-client`.

Login JSON: `{"usuario":"TU_USUARIO_LOCAL","password":"TU_CLAVE_LOCAL"}`.
Creación y PUT: `{"titulo":"Cien años de soledad","autor":"Gabriel García Márquez"}`.
PUT reemplaza ambos campos editables: enviar ambos. Título de 1 a 200 y autor de 1 a 150 caracteres después de trim.
Campos adicionales, campos vacíos o tipos incorrectos producen 400; identificador inválido también produce 400.

## Demostración en Postman

1. Importar `postman/Biblioteca.postman_collection.json`.
2. En variables de la colección, completar localmente `usuario` y `password`, y revisar `baseUrl`. No crear variables de entorno con los mismos nombres: prevalecerían sobre las de colección.
3. Ejecutar `01 Login incorrecto` (401), luego `02 Login válido` (200). El script guarda el JWT en la variable de colección `token` automáticamente. Las operaciones heredan Bearer de la colección.
4. Ejecutar `03 Crear libro` (201). Guarda automáticamente `libroId`. Ejecutar `npm run db:libros` en otra terminal y capturar la fila insertada.
5. Ejecutar `04 Listar`, `05 Consultar ID` y `06 Actualizar`. Ejecutar nuevamente `npm run db:libros` y capturar el título modificado.
6. Ejecutar `07 Falta autor` (400) y las 15 peticiones de protección (401). Para el caso vencido, ejecutar `npm run token:expired` y copiar el token local generado en `expiredToken`. Tiene firma correcta, pero ya venció. Volver a consultar SQLite: ninguna de esas peticiones debe cambiar la fila.
7. Detener el servidor con Ctrl+C y volver a ejecutar `npm start`, conservando el mismo `.env` y archivo de base de datos. Ejecutar `08 Consultar después de reiniciar` y `npm run db:libros`. La fila debe seguir con el título actualizado.
8. Ejecutar `09 Eliminar` (204), `10 Consultar eliminado` (404), `11 Actualizar inexistente` y `12 Eliminar inexistente` (404). Ejecutar `npm run db:libros`: la fila ya no aparece.
9. Capturar respuestas de Postman sin mostrar el JWT, contraseñas ni cabeceras Authorization. Agregar las capturas al informe de entrega si el docente exige evidencia de la interfaz gráfica.

Consulta directa alternativa: abrir `data/biblioteca.sqlite` en DB Browser for SQLite y ejecutar:

```sql
SELECT id, titulo, autor FROM libros ORDER BY id;
```

`npm run db:libros` usa una conexión SQLite independiente; no llama a la API.
No publicar la colección con valores locales sensibles; limpiar `password`, `token` y `expiredToken` antes de exportarla.

## Comprobación automática reproducible

```sh
npm test
```

Ejecuta la colección exportada mediante Newman, arranca un servidor con puerto local y base temporales, crea una cuenta con contraseña aleatoria, prueba los 27 requests, reinicia el proceso y comprueba cinco consultas directas a SQLite. No requiere `.env` ni modifica la base de trabajo. Elimina los datos temporales y guarda únicamente respuestas saneadas en `evidence/resultados.json`.
El informe PDF incluido documenta esta ejecución real: 31 aserciones, cero fallos. No representa capturas de la aplicación Postman. Las capturas gráficas y la demostración individual en vivo quedan por realizar según la consigna.

Auditoría al preparar la entrega: `npm audit --omit=dev` indicó cero vulnerabilidades de producción. Newman 6.2.3 arrastra 19 avisos de dependencias de desarrollo (6 moderados, 12 altos y 1 crítico); no se resolvieron mediante una degradación forzada. Usarlo únicamente para esta colección local de confianza. Para ejecutar solo la API puede instalarse con `npm ci --omit=dev`; `npm test` necesita las dependencias de desarrollo.

## Organización y explicación técnica

- `src/server.js`: recibe JSON, monta rutas y responde errores.
- `src/auth.js`: valida login, firma JWT y verifica firma, expiración, emisor y audiencia antes del CRUD.
- `src/password.js`: hash scrypt con sal y comparación de tiempo constante.
- `src/books.js`: validación y consultas parametrizadas de libros.
- `src/db.js`: abre el archivo SQLite y aplica el esquema.
- `scripts/`: inicialización, consulta directa y prueba reproducible.
- `schema.sql`: tablas de usuarios y libros.

Recorrido de una actualización: Express recibe `PUT /libros/:id`, `authenticate` verifica JWT; el router valida identificador y campos; la consulta `UPDATE ... WHERE id = ?` usa parámetros; si `changes` es cero responde 404 y si actualizó devuelve la fila almacenada con 200.
El JWT no almacena la contraseña y no se guarda en la base. Firmarlo permite detectar cambios; verificar `exp` rechaza tokens vencidos. El hash de contraseña no es cifrado reversible. La persistencia se demuestra consultando el mismo archivo SQLite desde otra conexión tras reiniciar el proceso.

## Entrega

El ZIP contiene código fuente, `package.json`, `package-lock.json`, `.env.example`, colección Postman, SQL, README, JSON saneado de resultados y PDF.
No contiene `node_modules`, `.env`, archivos de base de datos, contraseñas reales ni tokens vigentes.

Referencias oficiales: [SQLite en Node.js](https://nodejs.org/download/release/v24.14.0/docs/api/sqlite.html), [rutas Express](https://expressjs.com/en/guide/routing/), [middleware Express](https://expressjs.com/en/guide/using-middleware/).

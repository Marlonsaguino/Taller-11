const express = require('express');
const { port } = require('./config');
const db = require('./db');
const { router, authenticate } = require('./auth');
const app = express();
app.disable('x-powered-by');
app.use(express.json({ limit: '16kb' }));
app.use('/auth', router);
app.use('/libros', authenticate, require('./books'));
app.use((req, res) => res.status(404).json({ error: 'Ruta no encontrada.' }));
app.use((err, req, res, next) => {
  const status = err.status === 400 ? 400 : err.status === 413 ? 413 : 500;
  if (status === 500) console.error('Error interno en la petición.');
  res.status(status).json({ error: status === 400 ? 'JSON inválido.' : status === 413 ? 'Petición demasiado grande.' : 'Error interno.' });
});
const server = app.listen(port, '127.0.0.1');
server.once('listening', () => console.log(`API en http://127.0.0.1:${server.address().port}`));
server.once('error', err => {
  if (err.code === 'EADDRINUSE') console.error(`El puerto ${port} está ocupado. Detenga la otra instancia o cambie PORT en .env.`);
  else console.error(`No se pudo iniciar la API (${err.code || 'ERROR'}): ${err.message}`);
  db.close();
  process.exitCode = 1;
});
function close() { server.close(() => { db.close(); process.exit(0); }); }
process.on('SIGTERM', close); process.on('SIGINT', close);

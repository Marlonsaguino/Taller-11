require('dotenv').config({ quiet: true });
const path = require('node:path');
const secret = process.env.JWT_SECRET;
if (!secret || Buffer.byteLength(secret) < 32) throw new Error('JWT_SECRET debe tener al menos 32 bytes. Ejecute npm run setup.');
module.exports = { secret, database: path.resolve(process.env.DATABASE_PATH || './data/biblioteca.sqlite'), port: Number(process.env.PORT || 3000) };

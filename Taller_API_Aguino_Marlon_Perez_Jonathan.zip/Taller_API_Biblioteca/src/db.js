const { DatabaseSync } = require('node:sqlite');
const fs = require('node:fs');
const path = require('node:path');
const config = require('./config');
fs.mkdirSync(path.dirname(config.database), { recursive: true });
const db = new DatabaseSync(config.database);
db.exec('PRAGMA foreign_keys = ON; PRAGMA busy_timeout = 5000;');
db.exec(fs.readFileSync(path.join(__dirname, '../schema.sql'), 'utf8'));
module.exports = db;

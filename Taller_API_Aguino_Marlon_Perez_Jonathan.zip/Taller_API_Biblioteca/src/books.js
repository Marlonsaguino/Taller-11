const router = require('express').Router();
const db = require('./db');
router.param('id', (req, res, next, id) => {
  if (!/^[1-9]\d*$/.test(id) || !Number.isSafeInteger(Number(id))) return res.status(400).json({ error: 'Identificador inválido.' });
  req.bookId = Number(id); next();
});
function validate(req, res, next) {
  const body = req.body;
  if (!body || Array.isArray(body) || Object.keys(body).some(k => !['titulo', 'autor'].includes(k)) ||
      typeof body.titulo !== 'string' || typeof body.autor !== 'string' ||
      !body.titulo.trim() || !body.autor.trim() || body.titulo.trim().length > 200 || body.autor.trim().length > 150)
    return res.status(400).json({ error: 'Se requieren titulo (1-200) y autor (1-150). No se aceptan otros campos.' });
  req.book = { titulo: body.titulo.trim(), autor: body.autor.trim() }; next();
}
const find = id => db.prepare('SELECT id, titulo, autor FROM libros WHERE id = ?').get(id);
router.get('/', (req, res) => res.json(db.prepare('SELECT id, titulo, autor FROM libros ORDER BY id').all()));
router.get('/:id', (req, res) => {
  const book = find(req.bookId);
  return book ? res.json(book) : res.status(404).json({ error: 'Libro no encontrado.' });
});
router.post('/', validate, (req, res) => {
  const result = db.prepare('INSERT INTO libros (titulo, autor) VALUES (?, ?)').run(req.book.titulo, req.book.autor);
  const book = find(Number(result.lastInsertRowid));
  res.location(`/libros/${book.id}`).status(201).json(book);
});
router.put('/:id', validate, (req, res) => {
  const result = db.prepare('UPDATE libros SET titulo = ?, autor = ? WHERE id = ?').run(req.book.titulo, req.book.autor, req.bookId);
  return result.changes ? res.json(find(req.bookId)) : res.status(404).json({ error: 'Libro no encontrado.' });
});
router.delete('/:id', (req, res) => {
  const result = db.prepare('DELETE FROM libros WHERE id = ?').run(req.bookId);
  return result.changes ? res.status(204).end() : res.status(404).json({ error: 'Libro no encontrado.' });
});
module.exports = router;

const express = require('express');
const jwt = require('jsonwebtoken');
const db = require('./db');
const { secret } = require('./config');
const { hash, verify } = require('./password');
const dummy = hash('dummy-comparison-only');
const options = { algorithms: ['HS256'], issuer: 'biblioteca-api', audience: 'biblioteca-client' };
const router = express.Router();
router.post('/login', (req, res) => {
  const { usuario, password } = req.body || {};
  if (typeof usuario !== 'string' || typeof password !== 'string' || usuario.length > 100 || password.length > 256) return res.status(400).json({ error: 'Se requieren usuario y password válidos.' });
  const user = db.prepare('SELECT * FROM usuarios WHERE usuario = ?').get(usuario);
  const valid = verify(password, user?.password_hash || dummy);
  if (!user || !valid) return res.status(401).json({ error: 'Credenciales incorrectas.' });
  const token = jwt.sign({}, secret, { algorithm: 'HS256', subject: String(user.id), issuer: options.issuer, audience: options.audience, expiresIn: '15m' });
  res.json({ token, token_type: 'Bearer', expires_in: 900 });
});
function authenticate(req, res, next) {
  const match = /^Bearer (\S+)$/i.exec(req.headers.authorization || '');
  if (!match) return res.status(401).json({ error: 'Se requiere Authorization: Bearer <token>.' });
  try { req.auth = jwt.verify(match[1], secret, options); next(); }
  catch { res.status(401).json({ error: 'Token inválido o vencido.' }); }
}
module.exports = { router, authenticate };

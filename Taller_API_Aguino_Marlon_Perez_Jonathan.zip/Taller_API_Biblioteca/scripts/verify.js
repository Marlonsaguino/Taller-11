// Ejecuta la colección real con Newman y consulta SQLite por otra conexión.
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const assert = require('node:assert/strict');
const { spawn } = require('node:child_process');
const { randomBytes } = require('node:crypto');
const { DatabaseSync } = require('node:sqlite');
const jwt = require('jsonwebtoken');
const newman = require('newman');
const { hash } = require('../src/password');
const collection = require('../postman/Biblioteca.postman_collection.json');
const temp = fs.mkdtempSync(path.join(os.tmpdir(), 'biblioteca-test-'));
const database = path.join(temp, 'test.sqlite');
const secret = randomBytes(48).toString('hex');
const password = randomBytes(18).toString('hex');
const port = 31000 + Math.floor(Math.random() * 10000);
let child;
const evidence = { fecha: new Date().toISOString(), herramienta: 'Newman (motor de colecciones de Postman), sin interfaz gráfica', fases: [], baseDeDatos: [], reinicio: false };
const variables = { baseUrl: `http://127.0.0.1:${port}`, usuario: 'prueba', password, token: '', libroId: '', expiredToken: jwt.sign({}, secret, { algorithm: 'HS256', subject: '1', issuer: 'biblioteca-api', audience: 'biblioteca-client', expiresIn: -60 }) };
function start() {
  return new Promise((resolve, reject) => {
    child = spawn(process.execPath, ['src/server.js'], { env: { ...process.env, PORT: String(port), DATABASE_PATH: database, JWT_SECRET: secret }, windowsHide: true, stdio: ['ignore', 'pipe', 'pipe'] });
    const timeout = setTimeout(() => reject(new Error('Servidor no inició')), 10000);
    child.on('error', reject);
    child.on('exit', code => { if (code) reject(new Error(`Servidor terminó: ${code}`)); });
    child.stdout.on('data', data => { if (data.toString().includes('API en')) { clearTimeout(timeout); resolve(); } });
  });
}
async function stop() {
  if (!child || child.exitCode !== null) return;
  await new Promise(resolve => { child.once('exit', resolve); child.kill(); });
}
function snapshot(etapa) {
  const db = new DatabaseSync(database);
  const rows = db.prepare('SELECT id, titulo, autor FROM libros ORDER BY id').all(); db.close();
  evidence.baseDeDatos.push({ etapa, consulta: 'SELECT id, titulo, autor FROM libros ORDER BY id;', filas: rows }); return rows;
}
function run(name, items) {
  return new Promise((resolve, reject) => {
    const c = JSON.parse(JSON.stringify(collection)); c.item = items; c.variable = Object.entries(variables).map(([key, value]) => ({ key, value }));
    newman.run({ collection: c, reporters: [] }, (err, result) => {
      if (err) return reject(err);
      for (const execution of result.run.executions) {
        if (execution.item.name === '02 Login válido' && execution.response?.code === 200) variables.token = JSON.parse(execution.response.stream.toString()).token;
        if (execution.item.name === '03 Crear libro' && execution.response?.code === 201) variables.libroId = String(JSON.parse(execution.response.stream.toString()).id);
      }
      const executions = result.run.executions.map(x => ({ nombre: x.item.name, metodo: x.request.method, estado: x.response?.code, respuesta: x.item.name.includes('Login válido') ? { token: '[OMITIDO]', expires_in: 900 } : x.response?.stream?.length ? JSON.parse(x.response.stream.toString()) : null }));
      evidence.fases.push({ nombre: name, peticiones: executions, aserciones: result.run.stats.assertions.total, fallos: result.run.failures.length });
      if (result.run.failures.length) return reject(new Error(JSON.stringify(result.run.failures.map(x => ({ test: x.error.test, message: x.error.message })))));
      resolve();
    });
  });
}
(async () => {
  await start();
  const db = new DatabaseSync(database);
  db.prepare('INSERT INTO usuarios(usuario,password_hash) VALUES (?,?)').run('prueba', hash(password)); db.close();
  await run('Login y creación', collection.item.slice(0, 3));
  assert.equal(snapshot('Después de INSERT').length, 1);
  await run('Consulta y actualización', collection.item.slice(3, 6));
  const updated = snapshot('Después de UPDATE'); assert.match(updated[0].titulo, /edición revisada/);
  await run('Validación y protección de todas las operaciones', collection.item.slice(6, 22));
  assert.deepEqual(snapshot('Después de intentos rechazados'), updated);
  await stop(); await start(); evidence.reinicio = true;
  assert.deepEqual(snapshot('Después de reiniciar proceso Node.js'), updated);
  await run('Persistencia y eliminación', collection.item.slice(22));
  assert.equal(snapshot('Después de DELETE').length, 0);
  evidence.resultado = 'APROBADO';
  fs.mkdirSync('evidence', { recursive: true });
  fs.writeFileSync('evidence/resultados.json', JSON.stringify(evidence, null, 2));
  console.log(JSON.stringify({ resultado: evidence.resultado, peticiones: evidence.fases.reduce((n, f) => n + f.peticiones.length, 0), aserciones: evidence.fases.reduce((n, f) => n + f.aserciones, 0), reinicio: evidence.reinicio, consultasDirectas: evidence.baseDeDatos.length }, null, 2));
})().catch(err => { console.error(err); process.exitCode = 1; }).finally(async () => { await stop(); fs.rmSync(temp, { recursive: true, force: true }); });


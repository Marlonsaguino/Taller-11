const readline = require('node:readline/promises');
const { hash } = require('../src/password');
const db = require('../src/db');
(async () => {
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
  try {
    const usuario = (process.env.TEST_USER || await rl.question('Usuario de prueba: ')).trim();
    const password = process.env.TEST_PASSWORD || await rl.question('Contraseña local (se verá al escribir): ');
    if (!usuario || usuario.length > 100 || password.length < 12 || password.length > 256) throw new Error('Usuario requerido (hasta 100); contraseña de 12 a 256 caracteres.');
    db.prepare('INSERT INTO usuarios (usuario, password_hash) VALUES (?, ?) ON CONFLICT(usuario) DO UPDATE SET password_hash=excluded.password_hash').run(usuario, hash(password));
    console.log('Cuenta inicializada; solo se almacenó el hash scrypt.');
  } finally { rl.close(); db.close(); }
})().catch(err => { console.error(err.message); process.exitCode = 1; });

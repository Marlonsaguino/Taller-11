const jwt = require('jsonwebtoken');
const { secret } = require('../src/config');
console.log(jwt.sign({}, secret, { algorithm: 'HS256', issuer: 'biblioteca-api', audience: 'biblioteca-client', subject: '1', expiresIn: -60 }));

const fs = require('node:fs');
const items = [];
function request(name, method, route, status, body, auth, extra = []) {
  const req = { method, header: [{ key: 'Content-Type', value: 'application/json' }], url: '{{baseUrl}}' + route };
  if (auth !== undefined) req.auth = auth === false ? { type: 'noauth' } : { type: 'bearer', bearer: [{ key: 'token', value: auth, type: 'string' }] };
  if (body !== undefined) req.body = { mode: 'raw', raw: JSON.stringify(body), options: { raw: { language: 'json' } } };
  items.push({ name, request: req, event: [{ listen: 'test', script: { type: 'text/javascript', exec: [`pm.test('HTTP ${status}', () => pm.response.to.have.status(${status}));`, ...extra] } }] });
}
request('01 Login incorrecto', 'POST', '/auth/login', 401, { usuario: '{{usuario}}', password: 'incorrecta' }, false);
request('02 Login válido', 'POST', '/auth/login', 200, { usuario: '{{usuario}}', password: '{{password}}' }, false, ["if (pm.response.code === 200) pm.collectionVariables.set('token', pm.response.json().token);", "pm.test('JWT con vencimiento', () => pm.expect(pm.response.json().expires_in).to.equal(900));"]);
request('03 Crear libro', 'POST', '/libros', 201, { titulo: 'Cien años de soledad', autor: 'Gabriel García Márquez' }, undefined, ["if (pm.response.code === 201) pm.collectionVariables.set('libroId', String(pm.response.json().id));"]);
request('04 Listar', 'GET', '/libros', 200, undefined, undefined, ["pm.test('Lista contiene el libro', () => pm.expect(pm.response.json().some(x => String(x.id) === pm.collectionVariables.get('libroId'))).to.equal(true));"]);
request('05 Consultar ID', 'GET', '/libros/{{libroId}}', 200);
request('06 Actualizar', 'PUT', '/libros/{{libroId}}', 200, { titulo: 'Cien años de soledad - edición revisada', autor: 'Gabriel García Márquez' }, undefined, ["pm.test('Título actualizado', () => pm.expect(pm.response.json().titulo).to.include('edición revisada'));"]);
request('07 Falta autor', 'POST', '/libros', 400, { titulo: 'Incompleto' });
for (const [label, auth] of [['sin token', false], ['token inválido', 'token-invalido'], ['token vencido', '{{expiredToken}}']]) {
  for (const [method, route, body] of [['POST', '/libros', { titulo: 'No autorizado', autor: 'Prueba' }], ['GET', '/libros'], ['GET', '/libros/{{libroId}}'], ['PUT', '/libros/{{libroId}}', { titulo: 'No autorizado', autor: 'Prueba' }], ['DELETE', '/libros/{{libroId}}']]) request(`${method} ${label}`, method, route, 401, body, auth);
}
request('08 Consultar después de reiniciar', 'GET', '/libros/{{libroId}}', 200, undefined, undefined, ["pm.test('Persistió actualización', () => pm.expect(pm.response.json().titulo).to.include('edición revisada'));"]);
request('09 Eliminar', 'DELETE', '/libros/{{libroId}}', 204);
request('10 Consultar eliminado', 'GET', '/libros/{{libroId}}', 404);
request('11 Actualizar inexistente', 'PUT', '/libros/{{libroId}}', 404, { titulo: 'No existe', autor: 'Prueba' });
request('12 Eliminar inexistente', 'DELETE', '/libros/{{libroId}}', 404);
const collection = { info: { name: 'Taller API - Biblioteca', schema: 'https://schema.getpostman.com/json/collection/v2.1.0/collection.json', description: 'Ejecutar hasta 07, verificar SQLite, reiniciar servidor y continuar desde 08. Las pruebas de 401 se ejecutan antes de 08. Completar usuario y password localmente; nunca exportar valores sensibles.' }, auth: { type: 'bearer', bearer: [{ key: 'token', value: '{{token}}', type: 'string' }] }, variable: ['baseUrl', 'usuario', 'password', 'token', 'libroId', 'expiredToken'].map(key => ({ key, value: key === 'baseUrl' ? 'http://127.0.0.1:3000' : '' })), item: items };
fs.mkdirSync('postman', { recursive: true });
fs.writeFileSync('postman/Biblioteca.postman_collection.json', JSON.stringify(collection, null, 2));

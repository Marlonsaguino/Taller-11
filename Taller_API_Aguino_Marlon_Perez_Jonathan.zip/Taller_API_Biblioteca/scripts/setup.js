const fs = require('node:fs');
const { randomBytes } = require('node:crypto');
if (!fs.existsSync('.env')) {
  fs.writeFileSync('.env', `PORT=3000\nDATABASE_PATH=./data/biblioteca.sqlite\nJWT_SECRET=${randomBytes(48).toString('hex')}\n`, { flag: 'wx' });
  console.log('.env creado con secreto aleatorio local.');
} else console.log('.env existente conservado.');

const db = require('../src/db');
console.log(JSON.stringify(db.prepare('SELECT id, titulo, autor FROM libros ORDER BY id').all(), null, 2));
db.close();
